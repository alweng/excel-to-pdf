
# This empty file should not be deleted!  It is used by external_programs.py
# to portably find the name of this directory on an arbitrary system.
# See that code for the details.

