#!/usr/bin/python
"""

This file just runs pdfCropMargins.py and allows the program to
be executed by running Python on the directory containing it.

"""

from __future__ import print_function, division, absolute_import
from .pdfCropMargins import main

main()

